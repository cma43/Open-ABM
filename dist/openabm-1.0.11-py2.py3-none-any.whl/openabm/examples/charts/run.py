from charts.server import server

server.launch()
