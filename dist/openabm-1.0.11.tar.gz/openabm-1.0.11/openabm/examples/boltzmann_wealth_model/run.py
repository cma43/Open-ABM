from boltzmann_wealth_model.server import server

server.launch()
